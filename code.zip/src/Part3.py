import csv
import datetime
import math

import numpy as np
import datetime as dt
import matplotlib.pyplot as plt
import matplotlib.pyplot as plt


import matplotlib.dates as mdates
from scipy.fftpack import fft, dct
from scipy.fftpack import ifft, idct
import numpy as np
import matplotlib.pyplot as plt
from matplotlib_venn import venn3
from matplotlib import pyplot as plt



from LogisticGrowthModel import localLogisticGrowth
from matplotlib.patches import Circle


data = {}

keyDates = [

            # New Years
            np.datetime64('2020-01-01'),
            np.datetime64('2021-01-01'),
            np.datetime64('2022-01-01'),
]

datesOfIntrest = [
            # local school lock down and busies slow down
            np.datetime64('2020-03-08'),
            # mask m adate
            np.datetime64('2020-10-17'),
            # 50% vac
            np.datetime64('2021-07-01'),
            # Omicron
            np.datetime64('2021-12-01'),
]

def main():
    print(dct(np.array([4., 3., 5., 10.]), 1))
    print(idct(dct(np.array([4., 3., 5., 10.]), 1), 1)/6)

    times = np.arange(np.datetime64('2020-01-01'),
                      np.datetime64('2022-02-01'))

    print(list(times).index(np.datetime64('2020-03-08')))
    print(list(times).index(np.datetime64('2020-10-17')))
    print(list(times).index(np.datetime64('2021-07-01')))
    print(list(times).index(np.datetime64('2021-12-01')))
    print(len(times))

    with open('data/NYTiems us-counties-2022.csv', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            if (not data.keys().__contains__(row['state'])):
                data[row['state']] = {}
            x = data.get(row['state'])
            # print(times.__contains__(np.datetime64(row['date'])))
            x[row['date']] = [float(row['cases_avg_per_100k']), float(row['deaths_avg_per_100k'])]

    for x in data.keys():
        for z in times:
            if not data[x].__contains__(str(z)):
                data[x][str(z)] = [float(0), float(0)]
    # print( list(times).index(np.datetime64('2022-01-01')))


    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%m/%d/%Y'))
    plt.gca().xaxis.set_major_locator(mdates.DayLocator())

    Nebraska= np.array(list(map(lambda x: (data['Nebraska'][str(x)][0] + 1,2), times)))
    Iowa= np.array(list(map(lambda x: (data['Iowa'][str(x)][0] + 1,2), times)))
    South_Dakota= np.array(list(map(lambda x: (data['South Dakota'][str(x)][0] + 1,2), times)))

    Nebraskadct = dct(np.array(list(map(lambda x: math.log(data['Nebraska'][str(x)][0] + 1, 2), times))))
    Iowadct  = dct(np.array(list(map(lambda x: math.log(data['Iowa'][str(x)][0] + 1, 2), times))))
    South_Dakotadct  = dct(np.array(list(map(lambda x: math.log(data['South Dakota'][str(x)][0] + 1, 2), times))))

    # Nebraskadct[-int(762 * 3/4):]=0
    # Iowadct[-int(762 * 3/4):] = 0
    # South_Dakotadct[-int(762 * 9/10):] = 0


    t1 =(Nebraska / 250 * 7)
    t2 =(Iowa / 250 * 7)
    t3 =(South_Dakota / 250 * 7)

    plt.plot(times,idct(Nebraskadct)*7.057558578556902/1.07557193e+04, label="log(Nebraska)")
    plt.plot(times,idct(Iowadct)*7.057558578556902/1.07557193e+04, label="log(Iowa)")
    plt.plot(times,idct(South_Dakotadct)*7.057558578556902/1.07557193e+04, label="log(South Dakota)")
    # plt.plot(times,  t1, label="Nebraska")
    # plt.plot(times,  t2, label="Iowa")
    # plt.plot(times,  t3, label="South Dakota")

    # plt.savefig("output/NISD.png")
    for date in  list(filter(lambda x:list(times).__contains__(x) ,keyDates)):
        plt.axvline(x=date, color='red')
    for date in list(filter(lambda x: list(times).__contains__(x), datesOfIntrest)):
        plt.axvline(x=date, color='blue')
    plt.legend(        loc=4,)
    plt.title('Covid data in Nebraska, Iowa and  South Dakota')
    plt.show()




    # Xentropies = [HofFirstN[0], HofFirstN[2], HofLastN[0], HofLastN[2]]
    # Yentropies = [HofFirstN[1], HofFirstN[3], HofLastN[1], HofLastN[3]]

    # print("Xentropies")
    # print(Xentropies)
    #
    # print("Yentropies")
    # print(Yentropies)








    titles = ['Lock downs (03-08-2020)', 'mask mandates (10-17-2020)',
              '50% vaccination rate (07-01-2021)', 'Omicron (12-01-2021)']

    # South Dakota.csv-EEEEEE-0.7020750364600461
    # Iowa.csv-EEEEEE-0.6738364665369696
    # Nebraska.csv-EEEEEE-0.6965591598385458

    # South Dakota.csv-Nebraska.csv-1.7150997644424828
    # South Dakota.csv-Iowa.csv-1.7450360497215314
    # Iowa.csv-Nebraska.csv-1.936016585961222
    # -1.6398, -1.8889, 0.6268, -1.8363, 0.5968, 0.8177, 1.1183
    v = venn3(subsets=(-1.8566,-2.2250,0.6073,-2.1612,0.6852,0.9375,0.8249))
    v.get_label_by_id('010').set_text('Nebraska')
    v.get_label_by_id('001').set_text('Iowa')
    v.get_label_by_id('100').set_text('South Dakota')
    plt.title("Mutual info between Nebraska, Iowa and South Dakota")
    plt.show()



    # MI all none->log->smoothed 1.1493265566915678
    # MI all none->log  1.3275040403290799
    # MI all none  0.9305149790034449

    fig, axarr = plt.subplots(nrows=2, ncols=2, figsize=(8, 8))

    mibnisd =[[-1.7121,-1.9717,0.0015,-2.1550,0.1847,0.4443,1.5259],
[-0.8693,-1.4005,0.3847,-1.1752,0.5878,0.7380,0.7974],
[-1.5903,-2.4141,0.0697,-2.3849,0.0405,0.8643,1.4801],
[-0.6196,-0.8850,0.2256,-0.7562,0.1584,0.3712,1.2065]]

    for ax1, ti,mi in zip(np.ravel(axarr),titles,mibnisd):

        v = venn3(subsets=(mi),ax=ax1)
        v.set_labels('')
        v.get_label_by_id('010').set_text('Nebraska')
        v.get_label_by_id('001').set_text('Iowa')
        v.get_label_by_id('100').set_text('South Dakota')
        ax1.set_title(ti)
        ax1.set_axis_on()

        ymin, ymax = ax1.get_ylim()
        ax1.set_ylim(ymin - 0.1, ymax)


        # ax.plot(v)

    plt.show()




    plt.show()
    plt.savefig("output/pt3_venn_diagrams.png")







    # Nebraska E 0.23331502166552193
    # Iowa     E 0.3443001713041654
    # South Dakota.csv E 0.31841866320855566

    # South Dakota.csv e 0.9942478486063331
    # Iowa.csv e 0.9284385671076849
    # Nebraska.csv e 0.9849152401415227



    # Iowa.csv - Nebraska.csv -  1.7412396886944517
    # South Dakota.csv - Iowa.csv - 1.5147488945690448
    # South Dakota.csv - Nebraska.csv - 1.464188652358589



    # South Dakota.csv-Nebraska.csv-1.8990317610443634
    # South Dakota.csv-Iowa.csv-1.9558412464695563
    # Iowa.csv - Nebraska.csv - 2.168461774834046











if __name__ == "__main__":
    main()
