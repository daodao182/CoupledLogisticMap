import csv
import datetime
import math

import numpy as np
import datetime as dt
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from scipy.fftpack import fft, dct
from scipy.fftpack import ifft, idct

data = {}


def main():
    times = np.arange(np.datetime64('2020-01-01'),
                      np.datetime64('2022-02-01'))

    with open('data/NYTiems us-counties-2022.csv', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            if (not data.keys().__contains__(row['state'])):
                data[row['state']] = {}
            x = data.get(row['state'])
            # print(times.__contains__(np.datetime64(row['date'])))
            x[row['date']] = [float(row['cases_avg_per_100k']), float(row['deaths_avg_per_100k'])]

    for x in data.keys():
        for z in times:
            if not data[x].__contains__(str(z)):
                data[x][str(z)] = [float(0), float(0)]



    for y in list(data.keys()):
        textfile = open("data/states/" + y + ".csv", "w")
        for element in list(map(lambda x: data[y][str(x)], times)):
            textfile.write(str(element[0])+","+str(element[1]) + "\n")
        textfile.close()


    for y in list(data.keys()):
        textfile = open("data/logstates/" + y + ".csv", "w")
        for element in list(map(lambda x: data[y][str(x)], times)):
            textfile.write(str(math.log(element[0]+1,2))+","+str(math.log(element[1]+1,2)) + "\n")
        textfile.close()

    for y in list(data.keys()):
        textfile = open("data/smothing/" + y + ".csv", "w")
        data0 = dct(np.array(list(map(lambda x: math.log(data[y][str(x)][0] + 1, 2), times))))
        data1 = dct(np.array(list(map(lambda x: math.log(data[y][str(x)][1] + 1, 2), times))))
        for element1, element2 in zip(idct(data0)*7.057558578556902/1.07557193e+04,idct(data1)*7.057558578556902/1.07557193e+04):
            textfile.write(str(math.log(element1+1, 2))+","+str(math.log(element2+1, 2)) + "\n")
        textfile.close()










if __name__ == "__main__":
    main()
