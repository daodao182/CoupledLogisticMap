This folder is used for deploying the infodynamics toolkit jar file to clojars.org, such that clojar users can utilise it. It is not required for users who simply wish to use the toolkit in clojar themselves.

