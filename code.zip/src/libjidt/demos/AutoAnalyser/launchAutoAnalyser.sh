#!/bin/bash

# Run the AutoAnalyser Launcher:
java -classpath "../../infodynamics.jar" infodynamics.demos.autoanalysis.AutoAnalyserLauncher -use-current-dir

