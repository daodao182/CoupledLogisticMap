package com.bacon;

import infodynamics.measures.discrete.TransferEntropyCalculatorDiscrete;
import infodynamics.utils.ArrayFileReader;
import infodynamics.utils.MatrixUtils;

public class part1dot0 {




    public static double TE() throws Exception {

        String dataFile = "/home/nicholas/IdeaProjects/trash/CS523-TopDownCausation/src/output/lastNtimesteps.txt";
        ArrayFileReader afr = new ArrayFileReader(dataFile);
        double[][] data = afr.getDouble2DMatrix();
        int[] source = MatrixUtils.discretise(
                MatrixUtils.selectColumn(data, 2), 2);
        int[] destination = MatrixUtils.discretise(
                MatrixUtils.selectColumn(data, 3), 2);

        // 1. Construct the calculator:

        for (int i = 0; i < 5; i++) {
            TransferEntropyCalculatorDiscrete calc
                    = new TransferEntropyCalculatorDiscrete(2, i, 1, 1, 1, 1);
            // 2. No other properties to set for discrete calculators.
            // 3. Initialise the calculator for (re-)use:
            calc.initialise();
            // 4. Supply the sample data:
            calc.addObservations(source, destination);
            // 5. Compute the estimate:
            double result = calc.computeAverageLocalOfObservations();

            System.out.printf("k="+i+"  %.4f bits\n",
                    result);
        }

        return 0;

    }

    public static void main(String[] args) throws Exception {
        TE();
    }
}



