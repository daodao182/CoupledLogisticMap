package com.bacon;

import infodynamics.measures.continuous.kernel.MutualInfoCalculatorMultiVariateKernel;
import infodynamics.measures.continuous.kraskov.ConditionalMutualInfoCalculatorMultiVariateKraskov1;
import infodynamics.measures.discrete.EntropyCalculatorDiscrete;
import infodynamics.utils.ArrayFileReader;
import infodynamics.utils.MatrixUtils;
import java.io.File;
import java.util.LinkedList;

public class part3Dot0 {






        public static double CMI_Kraskov(String data1, String data2, String data3, int start, int amount) throws Exception {

                ArrayFileReader afr1 = new ArrayFileReader(data1);
                ArrayFileReader afr2 = new ArrayFileReader(data2);
                ArrayFileReader afr3 = new ArrayFileReader(data3);
                double[][] data_1 = afr1.getDouble2DMatrix();
                double[] source = MatrixUtils.selectColumn(data_1, 0);
                double[][] data_2 = afr2.getDouble2DMatrix();
                double[] destination = MatrixUtils.selectColumn(data_2, 0);
                double[][] data_3 = afr3.getDouble2DMatrix();
                double[] conditional = MatrixUtils.selectColumn(data_3, 0);

            double[] sourceResized ;
            double[] destinationResized ;
            double[] conditionalResized ;

            if (start==-1){
                sourceResized=source;
                destinationResized=destination;
                conditionalResized=conditional;
            }else {
                destinationResized = new double[amount];
                sourceResized = new double[amount];
                conditionalResized = new double[amount];
                for (int i = 0; i < amount; i++) {
                    sourceResized[i] = source[start+i];
                    destinationResized[i] = destination[start+i];
                    conditionalResized[i]=conditional[start+i];
                }


            }



                // 1. Construct the calculator:
                ConditionalMutualInfoCalculatorMultiVariateKraskov1 calc;
                calc = new ConditionalMutualInfoCalculatorMultiVariateKraskov1();
                // 2. Set any properties to non-default values:
                // No properties were set to non-default values
                // 3. Initialise the calculator for (re-)use:
                calc.initialise();
                // 4. Supply the sample data:
                calc.setObservations(sourceResized, destinationResized, conditionalResized);
                // 5. Compute the estimate:
                double result = calc.computeAverageLocalOfObservations();

//                System.out.printf("CMI_Kraskov (KSG) alg. 1(col_0 -> col_1 | col_2) = %.4f bits\n",
//                        result*1.442695);

        return result*Math.log10(Math.E)/Math.log10(2);


    }



    public static double MI(String data1, String data2,int start, int amount) throws Exception {


        ArrayFileReader afr1 = new ArrayFileReader(data1);
        double[][] data_1 = afr1.getDouble2DMatrix();

        ArrayFileReader afr2 = new ArrayFileReader(data2);
        double[][] data_2 = afr2.getDouble2DMatrix();
        double[] source = MatrixUtils.selectColumn(data_1, 0);
        double[] destination = MatrixUtils.selectColumn(data_2, 0);

        double[] sourceResized ;
        double[] destinationResized ;

        if (start==-1){
            sourceResized=source;
            destinationResized=destination;
        }else {
            destinationResized = new double[amount];
            sourceResized = new double[amount];
            for (int i = 0; i < amount; i++) {
                sourceResized[i] = source[start+i];
                destinationResized[i] = destination[start+i];
            }


        }




        // 1. Construct the calculator:
        MutualInfoCalculatorMultiVariateKernel calc;
        calc = new MutualInfoCalculatorMultiVariateKernel();
        // 2. Set any properties to non-default values:
        // No properties were set to non-default values
        // 3. Initialise the calculator for (re-)use:
        calc.initialise();
        // 4. Supply the sample data:
        calc.setObservations(sourceResized, destinationResized);
        // 5. Compute the estimate:
        double result = calc.computeAverageLocalOfObservations();
        if (Double.isNaN(result)){
            return 0.0;

        }else {
             return result;
        }
    }
    public static double E(String data1,int start, int amount) throws Exception {

        // 0. Load/prepare the data:
        ArrayFileReader afr = new ArrayFileReader(data1);
        double[][] data = afr.getDouble2DMatrix();
        int[] variable = MatrixUtils.discretise(
                MatrixUtils.selectColumn(data, 0), 2);

        // 1. Construct the calculator:



        int[] variableResized ;


        if (start==-1){
            variableResized=variable;

        }else {
            variableResized = new int[amount];
            for (int i = 0; i < amount; i++) {
                variableResized[i] = variable[start+i];

            }


        }




        EntropyCalculatorDiscrete calc
                = new EntropyCalculatorDiscrete(2);
        // 2. No other properties to set for discrete calculators.
        // 3. Initialise the calculator for (re-)use:
        calc.initialise();
        // 4. Supply the sample data:
        calc.addObservations(variableResized);
        // 5. Compute the estimate:
        double result = calc.computeAverageLocalOfObservations();


        if (Double.isNaN(result)){
            return 0.0;

        }else {
            return result;
        }
    }

    public static void main(String[] args) throws Exception {
        File dataFolder = new File("/home/nicholas/IdeaProjects/trash/CS523-TopDownCausation/src/data/smothing")   ;
        File[] csv = dataFolder.listFiles();

        LinkedList<Double> allMI= new LinkedList<>();
        double maxMI =0;
        double maxE =100000;
        for (int i = 0; i < csv.length; i++) {
            double value1 = E(csv[i].getAbsolutePath(),-1,-1);
            System.out.println(csv[i].getName()+"-EEEEEE-"+value1);
            maxE = Math.min(maxE,value1);
            for (int j = 0; j <i ; j++) {


                    double value = MI(csv[i].getAbsolutePath(),csv[j].getAbsolutePath(),-1,-1);
                    System.out.println(csv[i].getName()+"-"+csv[j].getName()+"-"+value);
                maxMI = Math.max(maxMI,value);
                allMI.add(value);

            }



        }








  }
}
