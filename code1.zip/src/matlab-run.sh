#!/usr/bin/env bash

matlab -batch "TEcalc"
matlab -batch "MIcalc"
matlab -batch "plotCI"