package com.bacon;

import static com.bacon.part3Dot0.MI;
import static com.bacon.part3Dot0.*;

public class part3Dot1 {

    public static void ven3way(String s1, String s2, String s3, int start, int size) throws Exception {


        double Hs1= E(s1,start,size) ;
        double Hs2= E(s2,start,size);
        double Hs3= E(s3,start,size);

        double s1s2MI  = MI(s1,s2,start,size);
        double s2s3MI  = MI(s2,s3,start,size);
        double s1s3MI  = MI(s1,s3,start,size);


        double Is1s2s3  = s1s2MI -  CMI_Kraskov(s1,s2,s3,start,size);

        double I123 = Is1s2s3;
        double I12M3 = s1s2MI-I123;
        double I23M1 = s2s3MI-I123;
        double I13M2 = s1s3MI-I123;
        double H1m =Hs1-I12M3-I13M2    -I123 ;
        double H2m =Hs2-I12M3-I23M1    -I123 ;
        double H3m =Hs3-I13M2-I23M1    -I123 ;


        System.out.printf("[%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f]\n",
                H1m,H2m,I12M3,H3m,I13M2,I23M1,I123
        );



    }

        public static void main(String[] args) throws Exception {
//        String  s1= args[0];
//        String  s2= args[1];
//        String  s3= args[2];
//
//
//        int start = Integer.parseInt(args[3]);
//        int size = Integer.parseInt(args[4]);

       String  s1=  "/home/nicholas/IdeaProjects/trash/CS523-TopDownCausation/src/data/states/South Dakota.csv";
       String  s2=          "/home/nicholas/IdeaProjects/trash/CS523-TopDownCausation/src/data/states/Nebraska.csv";
       String  s3=          "/home/nicholas/IdeaProjects/trash/CS523-TopDownCausation/src/data/states/Iowa.csv";
             int start = Integer.parseInt("67");
       int size = Integer.parseInt("60");

            ven3way( s1,  s2,  s3,  67,  size);
            ven3way( s1,  s2,  s3,  290,  size);
            ven3way( s1,  s2,  s3,  547,  size);
            ven3way( s1,  s2,  s3,  700,  size);





        }
}
