MIcalc;
TEcalc;
plotCI;


