#!/usr/bin/env bash

# Construct the output directory structure
/home/nicholas/IdeaProjects/trash/CS523-TopDownCausation/venv/bin/python3 ./build_paths.py
/home/nicholas/IdeaProjects/trash/CS523-TopDownCausation/venv/bin/python3 ./part0.py
java -cp libjidt/infodynamics.jar  com.bacon.GeneratedCalculator > output/mi.json
/home/nicholas/IdeaProjects/trash/CS523-TopDownCausation/venv/bin/python3 ./part1.py



/home/nicholas/IdeaProjects/trash/CS523-TopDownCausation/venv/bin/python3 ./logistic_map.py
/home/nicholas/IdeaProjects/trash/CS523-TopDownCausation/venv/bin/python3 ./part4.py

#matlab -batch "MIcalc"
#matlab -batch "TEcalc"
#matlab -batch "plotCI"
